package com.project.MTB.service;

import java.util.List;

import com.project.MTB.dto.BookingDto;
import com.project.MTB.entity.Booking;
import com.project.MTB.exception.MovieException;


public interface IBookingService {
	public List<Booking> getAll();
	public Booking bookTicket(BookingDto bookings) throws MovieException;
	public List<Booking> getAllMyBookings();
	public String cancelMyBooking(int bookingId) throws MovieException;

}
