package com.project.MTB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieTicketMidtermDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieTicketMidtermDemoApplication.class, args);
	}

}
