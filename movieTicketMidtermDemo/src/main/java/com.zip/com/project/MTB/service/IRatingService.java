package com.project.MTB.service;

import java.util.List;

import com.project.MTB.dto.RatingDto;
import com.project.MTB.entity.Rating;
import com.project.MTB.exception.MovieException;


public interface IRatingService {
	public Rating addReview(RatingDto ratingsDTO) throws MovieException;
	public List<Rating> getRatingsBymovieName(String moviename);


}
