package com.project.MTB.entity;

import java.sql.Date;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import java.sql.Time;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
public class Shows {
	
	@Id
	@Column(name = "show_id")
	int showId;

	@ManyToOne
	@JoinColumn(name = "theatre_id")
	private Theater theatre;

	@ManyToOne
	@JoinColumn(name = "movie_id")
	private Movie movie;

	@Column(name = "show_date")
	Date showDate;

	@Column(name = "show_time")
	Time showTime;

	@Column(name = "available_seats")
	int availableSeats;


}
